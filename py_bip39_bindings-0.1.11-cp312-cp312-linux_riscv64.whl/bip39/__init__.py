from .bip39 import *

__doc__ = bip39.__doc__
if hasattr(bip39, "__all__"):
    __all__ = bip39.__all__